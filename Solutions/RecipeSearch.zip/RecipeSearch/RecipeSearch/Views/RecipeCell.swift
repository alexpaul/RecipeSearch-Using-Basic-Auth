//
//  RecipeCell.swift
//  RecipeSearch
//
//  Created by Alex Paul on 12/11/19.
//  Copyright © 2019 Alex Paul. All rights reserved.
//

import UIKit

class RecipeCell: UITableViewCell {

  @IBOutlet weak var recipeImageView: UIImageView!
  @IBOutlet weak var recipeLabel: UILabel!
  
  private var urlString = ""
  
  func configureCell(for recipe: Recipe) {
    recipeLabel.text = recipe.label
    
    self.urlString = recipe.image
    
    recipeImageView.getImage(with: recipe.image) { [weak self] (result) in
      switch result {
      case .failure:
        DispatchQueue.main.async {
          self?.recipeImageView.image = UIImage(systemName: "exclaimation-mark")
        }
      case .success(let image):
        DispatchQueue.main.async {
          if self?.urlString == recipe.image {
             self?.recipeImageView.image = image
          }
        }
      }
    }
    
    
  }
  
  override func prepareForReuse() {
    super.prepareForReuse()
    recipeImageView.image = nil
  }

}
