//
//  Secrets.swift
//  RecipeSearch
//
//  Created by Alex Paul on 12/10/19.
//  Copyright © 2019 Alex Paul. All rights reserved.
//

import Foundation

struct SecretKey {
  static let appId = "e5b042ea"
  static let appkey = "5ac9e6bea5408890cdd8487d0347b611"
}
