# RecipeSearch-Temp

Working with API keys and URLSession to search for recipes using the Edamam recipes API. In the process we will  include a Secrets folder and .gitignore file to ignore pushing our API keys.
